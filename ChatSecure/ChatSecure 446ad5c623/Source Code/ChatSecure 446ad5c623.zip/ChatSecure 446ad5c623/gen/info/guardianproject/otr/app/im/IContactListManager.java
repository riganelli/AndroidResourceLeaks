/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Users\\beloz\\Desktop\\ChatSecure 446ad5c623\\src\\info\\guardianproject\\otr\\app\\im\\IContactListManager.aidl
 */
package info.guardianproject.otr.app.im;
public interface IContactListManager extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements info.guardianproject.otr.app.im.IContactListManager
{
private static final java.lang.String DESCRIPTOR = "info.guardianproject.otr.app.im.IContactListManager";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an info.guardianproject.otr.app.im.IContactListManager interface,
 * generating a proxy if needed.
 */
public static info.guardianproject.otr.app.im.IContactListManager asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof info.guardianproject.otr.app.im.IContactListManager))) {
return ((info.guardianproject.otr.app.im.IContactListManager)iin);
}
return new info.guardianproject.otr.app.im.IContactListManager.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_registerContactListListener:
{
data.enforceInterface(DESCRIPTOR);
info.guardianproject.otr.app.im.IContactListListener _arg0;
_arg0 = info.guardianproject.otr.app.im.IContactListListener.Stub.asInterface(data.readStrongBinder());
this.registerContactListListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_unregisterContactListListener:
{
data.enforceInterface(DESCRIPTOR);
info.guardianproject.otr.app.im.IContactListListener _arg0;
_arg0 = info.guardianproject.otr.app.im.IContactListListener.Stub.asInterface(data.readStrongBinder());
this.unregisterContactListListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_registerSubscriptionListener:
{
data.enforceInterface(DESCRIPTOR);
info.guardianproject.otr.app.im.ISubscriptionListener _arg0;
_arg0 = info.guardianproject.otr.app.im.ISubscriptionListener.Stub.asInterface(data.readStrongBinder());
this.registerSubscriptionListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_unregisterSubscriptionListener:
{
data.enforceInterface(DESCRIPTOR);
info.guardianproject.otr.app.im.ISubscriptionListener _arg0;
_arg0 = info.guardianproject.otr.app.im.ISubscriptionListener.Stub.asInterface(data.readStrongBinder());
this.unregisterSubscriptionListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_getContactLists:
{
data.enforceInterface(DESCRIPTOR);
java.util.List _result = this.getContactLists();
reply.writeNoException();
reply.writeList(_result);
return true;
}
case TRANSACTION_getContactList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
info.guardianproject.otr.app.im.IContactList _result = this.getContactList(_arg0);
reply.writeNoException();
reply.writeStrongBinder((((_result!=null))?(_result.asBinder()):(null)));
return true;
}
case TRANSACTION_createContactList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.util.List<info.guardianproject.otr.app.im.engine.Contact> _arg1;
_arg1 = data.createTypedArrayList(info.guardianproject.otr.app.im.engine.Contact.CREATOR);
int _result = this.createContactList(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_deleteContactList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _result = this.deleteContactList(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_removeContact:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _result = this.removeContact(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_approveSubscription:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.approveSubscription(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_declineSubscription:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.declineSubscription(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_blockContact:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _result = this.blockContact(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_unBlockContact:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _result = this.unBlockContact(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_isBlocked:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
boolean _result = this.isBlocked(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_loadContactLists:
{
data.enforceInterface(DESCRIPTOR);
this.loadContactLists();
reply.writeNoException();
return true;
}
case TRANSACTION_getState:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getState();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements info.guardianproject.otr.app.im.IContactListManager
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void registerContactListListener(info.guardianproject.otr.app.im.IContactListListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_registerContactListListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void unregisterContactListListener(info.guardianproject.otr.app.im.IContactListListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_unregisterContactListListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void registerSubscriptionListener(info.guardianproject.otr.app.im.ISubscriptionListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_registerSubscriptionListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void unregisterSubscriptionListener(info.guardianproject.otr.app.im.ISubscriptionListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_unregisterSubscriptionListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Gets all the contact lists of this account.
     */
@Override public java.util.List getContactLists() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getContactLists, _data, _reply, 0);
_reply.readException();
java.lang.ClassLoader cl = (java.lang.ClassLoader)this.getClass().getClassLoader();
_result = _reply.readArrayList(cl);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Gets a contact list with specific name, return null if no contact list is found.
     */
@Override public info.guardianproject.otr.app.im.IContactList getContactList(java.lang.String name) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
info.guardianproject.otr.app.im.IContactList _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(name);
mRemote.transact(Stub.TRANSACTION_getContactList, _data, _reply, 0);
_reply.readException();
_result = info.guardianproject.otr.app.im.IContactList.Stub.asInterface(_reply.readStrongBinder());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int createContactList(java.lang.String name, java.util.List<info.guardianproject.otr.app.im.engine.Contact> contacts) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(name);
_data.writeTypedList(contacts);
mRemote.transact(Stub.TRANSACTION_createContactList, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int deleteContactList(java.lang.String name) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(name);
mRemote.transact(Stub.TRANSACTION_deleteContactList, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int removeContact(java.lang.String address) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(address);
mRemote.transact(Stub.TRANSACTION_removeContact, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Approves a subscription request from another user.
     */
@Override public void approveSubscription(java.lang.String address) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(address);
mRemote.transact(Stub.TRANSACTION_approveSubscription, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Declines a subscription request from another user.
     */
@Override public void declineSubscription(java.lang.String address) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(address);
mRemote.transact(Stub.TRANSACTION_declineSubscription, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public int blockContact(java.lang.String address) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(address);
mRemote.transact(Stub.TRANSACTION_blockContact, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int unBlockContact(java.lang.String address) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(address);
mRemote.transact(Stub.TRANSACTION_unBlockContact, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Tells if a certain contact is blocked.
     *
     * @param address the address of the contact.
     * @return true if it's blocked; false otherwise.
     */
@Override public boolean isBlocked(java.lang.String address) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(address);
mRemote.transact(Stub.TRANSACTION_isBlocked, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Explicitly load contact lists from the server. The user only needs to call this method if
     * autoLoadContacts is false when login; otherwise, contact lists will be downloaded from the
     * server automatically after login.
     */
@Override public void loadContactLists() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_loadContactLists, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public int getState() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_registerContactListListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_unregisterContactListListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_registerSubscriptionListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_unregisterSubscriptionListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getContactLists = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_getContactList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_createContactList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_deleteContactList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_removeContact = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_approveSubscription = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_declineSubscription = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_blockContact = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_unBlockContact = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_isBlocked = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_loadContactLists = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_getState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
}
public void registerContactListListener(info.guardianproject.otr.app.im.IContactListListener listener) throws android.os.RemoteException;
public void unregisterContactListListener(info.guardianproject.otr.app.im.IContactListListener listener) throws android.os.RemoteException;
public void registerSubscriptionListener(info.guardianproject.otr.app.im.ISubscriptionListener listener) throws android.os.RemoteException;
public void unregisterSubscriptionListener(info.guardianproject.otr.app.im.ISubscriptionListener listener) throws android.os.RemoteException;
/**
     * Gets all the contact lists of this account.
     */
public java.util.List getContactLists() throws android.os.RemoteException;
/**
     * Gets a contact list with specific name, return null if no contact list is found.
     */
public info.guardianproject.otr.app.im.IContactList getContactList(java.lang.String name) throws android.os.RemoteException;
public int createContactList(java.lang.String name, java.util.List<info.guardianproject.otr.app.im.engine.Contact> contacts) throws android.os.RemoteException;
public int deleteContactList(java.lang.String name) throws android.os.RemoteException;
public int removeContact(java.lang.String address) throws android.os.RemoteException;
/**
     * Approves a subscription request from another user.
     */
public void approveSubscription(java.lang.String address) throws android.os.RemoteException;
/**
     * Declines a subscription request from another user.
     */
public void declineSubscription(java.lang.String address) throws android.os.RemoteException;
public int blockContact(java.lang.String address) throws android.os.RemoteException;
public int unBlockContact(java.lang.String address) throws android.os.RemoteException;
/**
     * Tells if a certain contact is blocked.
     *
     * @param address the address of the contact.
     * @return true if it's blocked; false otherwise.
     */
public boolean isBlocked(java.lang.String address) throws android.os.RemoteException;
/**
     * Explicitly load contact lists from the server. The user only needs to call this method if
     * autoLoadContacts is false when login; otherwise, contact lists will be downloaded from the
     * server automatically after login.
     */
public void loadContactLists() throws android.os.RemoteException;
public int getState() throws android.os.RemoteException;
}
