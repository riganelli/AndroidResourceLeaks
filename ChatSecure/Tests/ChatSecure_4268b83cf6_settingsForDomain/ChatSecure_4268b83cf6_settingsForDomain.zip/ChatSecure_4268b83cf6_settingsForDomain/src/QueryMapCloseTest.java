import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class QueryMapCloseTest {
	AppiumDriver driver;

    final String APP_PACKAGE = "info.guardianproject.otr.app.im";
    final String APP_ACTIVITY = "app.WelcomeActivity";
    
    @Before
    public void SetUp() throws Exception {
        
    	//***SET UNITED STATES ENGLISH LANGUAGE IN THE DEVICE TO RUN THIS TEST CASE***
    	
    	DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "AndroidTestDevice");
        capabilities.setCapability(MobileCapabilityType.VERSION,"5.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        //capabilities.setCapability("locale", "en_US");
        //capabilities.setCapability("language", "en");
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        
        //wait the activity
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);

    }

    @Test
    public void TestRun() throws IOException, InterruptedException{
    	
    	//***SET UNITED STATES ENGLISH LANGUAGE IN THE DEVICE TO RUN THIS TEST CASE***
    	
    	findElementByText("", "android.widget.EditText").sendKeys("abcde");
    	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.ENTER);
    	
    	findElementByText("", "android.widget.EditText").sendKeys("abcde");
    	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.ENTER);
    	
    	findElementByText("Confirm passphrase", "android.widget.Button").click(); 
    	
    	Thread.sleep(2000);
    	
    	driver.findElement(By.id("New Account")).click();  
    	
    	Thread.sleep(2000);
    	
    	findElementByText("Create account","android.widget.TextView").click();
    	
    	Thread.sleep(2000);
    	
    	findElementByText("Connect via Tor (Requires Orbot app)","android.widget.CheckBox").click();
    }
    
    public WebElement findElementByText(String toSearch, String className) {
    	List<WebElement> elements = driver.findElementsByClassName(className);
    	for(WebElement  element: elements){
    		if(element.getText().equalsIgnoreCase(toSearch)) {
    			return element;
    		}
    	}
    	return null;
    }
}
