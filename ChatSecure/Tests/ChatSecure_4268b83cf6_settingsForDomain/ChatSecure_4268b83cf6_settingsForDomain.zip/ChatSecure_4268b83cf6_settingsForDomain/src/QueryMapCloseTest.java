import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;

public class QueryMapCloseTest {
	AppiumDriver driver;

    final String APP_PACKAGE = "info.guardianproject.otr.app.im";
    final String APP_ACTIVITY = "app.WelcomeActivity";
    
    @Before
    public void SetUp() throws Exception {
        
    	//***SET UNITED STATES ENGLISH LANGUAGE IN THE DEVICE TO RUN THIS TEST CASE***
    	
    	DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "AndroidTestDevice");
        capabilities.setCapability(MobileCapabilityType.VERSION,"5.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        //capabilities.setCapability("locale", "en_US");
        //capabilities.setCapability("language", "en");
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        
        //wait the activity
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);

    }

    @Test
    public void TestRun() throws IOException, InterruptedException{
    	
    	//***SET UNITED STATES ENGLISH LANGUAGE IN THE DEVICE TO RUN THIS TEST CASE***
    	
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.view.View/"
    			+ "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout/"
    			+ "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ViewFlipper/"
    			+ "android.widget.LinearLayout/android.widget.EditText")).sendKeys("abcde");
    	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.ENTER);
    	
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.view.View/"
    			+ "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout/"
    			+ "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ViewFlipper/"
    			+ "android.widget.LinearLayout/android.widget.EditText")).sendKeys("abcde");
    	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.ENTER);
    	
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.view.View/"
    			+ "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout/"
    			+ "android.widget.FrameLayout/android.widget.LinearLayout/android.widget.Button")).click();
    	
    	Thread.sleep(2000);
    	
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/"
    			+ "android.widget.FrameLayout/android.widget.FrameLayout/"
    			+ "android.widget.LinearLayout/android.widget.LinearLayout[3]/"
    			+ "android.widget.LinearLayout/android.widget.Button[1]")).click();
    	
    	Thread.sleep(2000);
    	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.MENU);
    	
    	Thread.sleep(2000);
    	
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/"
    			+ "android.widget.ListView/android.widget.LinearLayout[2]")).click();
    	
    	Thread.sleep(2000);
    	
    	driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"New Account\"]")).click();
    	
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/"
    			+ "android.widget.ListView/android.widget.LinearLayout[2]")).click();
    	
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/"
    			+ "android.widget.LinearLayout/android.widget.FrameLayout/"
    			+ "android.widget.FrameLayout/android.widget.ScrollView/"
    			+ "android.widget.LinearLayout/android.widget.CheckBox[2]")).click();  	
    }
}
