import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class CursorCloseTest {
	AppiumDriver driver;

    final String APP_PACKAGE = "info.guardianproject.otr.app.im";
    final String APP_ACTIVITY = "app.WelcomeActivity";
    
    @Before
    public void SetUp() throws Exception {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "AndroidTestDevice");
        capabilities.setCapability(MobileCapabilityType.VERSION,"4.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

        //wait the activity
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);

    }

    @Test
    public void TestRun() throws IOException, InterruptedException{
    	
    	findElementByText("Continue >>" , "android.widget.Button").click();
  	
    	Thread.sleep(2000);
    	
    	findElementByText("Add Account" , "android.widget.Button").click();
    	
    	Thread.sleep(1000);
    	
    	findElementByText("user@domain.com" , "android.widget.EditText").sendKeys("a@b.com");
    	
    	findElementByText("" , "android.widget.EditText").sendKeys("c");
    	
    	findElementByText("Sign in" , "android.widget.Button").click();
    	
    }
    
    public WebElement findElementByText(String toSearch, String className) {
    	List<WebElement> elements = driver.findElementsByClassName(className);
    	for(WebElement  element: elements){
    		if(element.getText().equalsIgnoreCase(toSearch)) {
    			return element;
    		}
    	}
    	return null;
    }
}