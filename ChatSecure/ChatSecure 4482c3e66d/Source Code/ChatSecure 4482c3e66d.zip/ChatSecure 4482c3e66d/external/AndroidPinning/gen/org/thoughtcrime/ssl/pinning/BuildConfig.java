/** Automatically generated file. DO NOT MODIFY */
package org.thoughtcrime.ssl.pinning;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}