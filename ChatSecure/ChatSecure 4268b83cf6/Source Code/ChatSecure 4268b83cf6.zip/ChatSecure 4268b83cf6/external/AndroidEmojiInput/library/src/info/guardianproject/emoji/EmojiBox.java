package info.guardianproject.emoji;

import android.content.Context;
import android.widget.LinearLayout;


public class EmojiBox extends LinearLayout {

	public EmojiBox(Context context) {
		super(context);
		
	}

}
