/** Automatically generated file. DO NOT MODIFY */
package info.guardianproject.otr.app.im;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}