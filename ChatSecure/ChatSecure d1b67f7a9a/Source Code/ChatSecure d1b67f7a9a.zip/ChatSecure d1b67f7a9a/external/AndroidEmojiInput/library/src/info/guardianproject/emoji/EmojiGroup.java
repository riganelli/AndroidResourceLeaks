package info.guardianproject.emoji;

import java.util.ArrayList;

public class EmojiGroup {

	String category;
	ArrayList<Emoji> emojis;
}
