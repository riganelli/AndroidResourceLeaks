package info.guardianproject.cacheword;

public interface ICacheWordBinder {

	CacheWordService getService();

}
