import java.io.IOException;
import java.net.URL;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class EventRecycleTest {
	AppiumDriver driver;

    @Before
    public void SetUp() throws Exception {
    	
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability(MobileCapabilityType.VERSION,"5.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.xabber.androiddev");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.xabber.android.ui.ContactList");
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, "com.xabber.android.ui.ContactList");
    }

    @Test
    public void TestRun () throws IOException, InterruptedException{
    	Thread.sleep(2000);
    	
    	WebElement submitbutton = driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/"
    			+ "android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/"
    			+ "android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.RelativeLayout/"
    			+ "android.widget.RelativeLayout/android.widget.Button"));
		
    	submitbutton.click();
		
    	login();
		
    	driver.findElement(By.xpath("hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/"
				+ "android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[1]/"
				+ "android.widget.LinearLayout/android.widget.HorizontalScrollView/android.widget.LinearLayout/"
				+ "android.widget.RelativeLayout/android.widget.ImageView[2]")).click();
    }
    
    public void login() throws IOException, InterruptedException{
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/"
    			+ "android.widget.FrameLayout[2]/android.widget.ScrollView/android.widget.LinearLayout/"
    			+ "android.widget.LinearLayout[1]/android.widget.EditText[1]")).sendKeys("test.android@xmpp.jp");
		
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/"
    			+ "android.widget.FrameLayout[2]/android.widget.ScrollView/android.widget.LinearLayout/"
    			+ "android.widget.LinearLayout[1]/android.widget.EditText[2]")).sendKeys("testpassword");
		
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/"
    			+ "android.widget.FrameLayout[2]/android.widget.ScrollView/android.widget.LinearLayout/"
    			+ "android.widget.LinearLayout[2]/android.widget.Button")).click();
    }

}