import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class EventRecycleTest {
	AppiumDriver driver;

    @Before
    public void SetUp() throws Exception {
    	
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability(MobileCapabilityType.VERSION,"5.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.xabber.androiddev");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.xabber.android.ui.ContactList");
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, "com.xabber.android.ui.ContactList");
    }

    @Test
    public void TestRun () throws IOException, InterruptedException{
    	Thread.sleep(2000);
    	
    	findElementByText("Add account","android.widget.Button").click();
		
    	login();
		
    	findElementByIndex(1,"android.widget.ImageView").click();
    }
    
    public void login() throws IOException, InterruptedException{
    	findElementByText("name@example.com","android.widget.EditText").sendKeys("test.android@xmpp.jp");
		
    	findElementByText("","android.widget.EditText").sendKeys("testpassword");
		
    	findElementByText("Add account","android.widget.Button").click();
    }
    
    public WebElement findElementByText(String toSearch, String className) {
    	List<WebElement> elements = driver.findElementsByClassName(className);
    	for(WebElement  element: elements){
    		if(element.getText().equalsIgnoreCase(toSearch)) {
    			return element;
    		}
    	}
    	return null;
    }
    
    public WebElement findElementByIndex(int index, String className) {
    	List<WebElement> elements = driver.findElementsByClassName(className);
    	int i = 0;
    	for(WebElement  element: elements){
    		if(i == index) {
    			return element;
    		}
    		i++;
    	}
    	return null;
    }

}