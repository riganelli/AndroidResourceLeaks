/** Automatically generated file. DO NOT MODIFY */
package org.connectbot.tests;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}