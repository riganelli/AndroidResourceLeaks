
package com.trilead.ssh2.channel;

/**
 * IChannelWorkerThread.
 * 
 * @author Christian Plattner, plattner@trilead.com
 * @version $Id: IChannelWorkerThread.java,v 1.1 2007/10/15 12:49:56 cplattne Exp $
 */
interface IChannelWorkerThread
{
	public void stopWorking();
}
