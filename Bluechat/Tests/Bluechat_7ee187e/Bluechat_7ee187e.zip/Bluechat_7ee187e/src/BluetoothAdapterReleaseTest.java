import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class BluetoothAdapterReleaseTest {
	AppiumDriver driver;

    final String APP_PACKAGE = "com.alexkang.bluechat";
    final String APP_ACTIVITY = "com.alexkang.bluechat.MainActivity"; 



    @Before
    public void SetUp() throws Exception {
    	DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability(MobileCapabilityType.VERSION,"5.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);

    }

    @Test
    public void TestRun() throws IOException, InterruptedException{	
    	//Try to enable bluetooth
    	Process process = Runtime.getRuntime().exec("adb shell am start -a android.bluetooth.adapter.action.REQUEST_ENABLE");
    	
    	Thread.sleep(2000);
    	
    	try {
    		findElementByText("YES","android.widget.Button").click();
    	} catch (Exception e) {
    		//Only if bluetooth is already enabled
    	}
    	
    	Thread.sleep(3000);
    	findElementByText("Join","android.widget.Button").click();
    	Thread.sleep(2000);	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.BACK);
    		
    }

    
    public WebElement findElementByText(String toSearch, String className) {
    	List<WebElement> elements = driver.findElementsByClassName(className);
    	for(WebElement  element: elements){
    		if(element.getText().equalsIgnoreCase(toSearch)) {
    			return element;
    		}
    	}
    	return null;
    }
}