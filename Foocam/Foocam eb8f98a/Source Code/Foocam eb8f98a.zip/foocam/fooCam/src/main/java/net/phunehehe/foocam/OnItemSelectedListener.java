package net.phunehehe.foocam;

import android.widget.AdapterView;

abstract class OnItemSelectedListener implements AdapterView.OnItemSelectedListener {

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
