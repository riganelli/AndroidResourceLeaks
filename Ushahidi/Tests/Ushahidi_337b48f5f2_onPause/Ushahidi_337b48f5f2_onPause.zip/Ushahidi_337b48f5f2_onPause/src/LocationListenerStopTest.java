import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;

public class LocationListenerStopTest {
	AppiumDriver driver;

    final String APP_PACKAGE = "com.ushahidi.android.app";
    final String APP_ACTIVITY = ".checkin.CheckinMap";

    @Before
    public void SetUp() throws Exception {
    	//first of all: enable gps
        Process process = Runtime.getRuntime().exec("adb shell settings put secure location_providers_allowed gps");
    	
    	DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "AndroidTestDevice");
        capabilities.setCapability(MobileCapabilityType.VERSION,"5.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

        //wait the activity
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);
    }

    @Test
    public void TestRun () throws IOException, InterruptedException {
    	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
    	
    	Thread.sleep(2000);
    	
    	Process process = Runtime.getRuntime().exec("adb shell dumpsys location");
        java.io.InputStream is = process.getInputStream();
        java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(is));

        String s = null;
        while ((s = reader.readLine()) != null) {
            if (s.contains("gps com.ushahidi.android.app")) {
                assert false;
            }
        }

    }
}
