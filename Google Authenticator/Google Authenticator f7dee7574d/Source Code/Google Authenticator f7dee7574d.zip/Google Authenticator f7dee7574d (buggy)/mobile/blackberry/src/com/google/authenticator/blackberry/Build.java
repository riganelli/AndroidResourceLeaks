package com.google.authenticator.blackberry;

public interface Build {
  String DOWNLOAD_URL = "http://bbhotp.appspot.com/";
}
