
package com.ichi2.anki.exception;

public class ConfirmModSchemaException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -9215098969154590797L;


    public ConfirmModSchemaException() {
    }
}
