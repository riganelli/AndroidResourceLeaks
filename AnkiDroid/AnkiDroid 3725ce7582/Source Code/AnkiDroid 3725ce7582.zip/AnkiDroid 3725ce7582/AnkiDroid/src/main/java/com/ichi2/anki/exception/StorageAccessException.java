
package com.ichi2.anki.exception;

public class StorageAccessException extends Exception {

    public StorageAccessException() {
    }


    public StorageAccessException(String msg) {
        super(msg);
    }
}
