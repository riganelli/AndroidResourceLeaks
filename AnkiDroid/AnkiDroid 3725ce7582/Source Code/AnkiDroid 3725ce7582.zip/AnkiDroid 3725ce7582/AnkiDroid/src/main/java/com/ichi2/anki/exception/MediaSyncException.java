
package com.ichi2.anki.exception;

public class MediaSyncException extends Exception {

    public MediaSyncException(String msg) {
        super(msg);
    }
}
