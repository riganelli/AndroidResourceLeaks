package com.ichi2.libanki.importer;

import com.ichi2.libanki.Collection;

/**
 * This class is a stub. Nothing is implemented yet.
 */
public class TextImporter extends NoteImporter {

    public TextImporter(Collection col, String file) {
        super(col, file);
    }

    @Override
    public void run() {

    }

    public void initMapping() {

    }

    public void setImportMode(int mode) {

    }
}
