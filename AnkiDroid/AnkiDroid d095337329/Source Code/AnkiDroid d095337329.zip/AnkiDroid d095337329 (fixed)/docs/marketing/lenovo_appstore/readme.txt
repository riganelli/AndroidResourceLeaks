Needs to generate a special APK after copying logo-IconGen.png to res/drawable/anki.png
