package com.ichi2.anki;

import android.content.Context;

public class FeedbackElement extends AbstractFeedbackElement {

    public FeedbackElement(Context context) {
        super.setContext(context);
    }
}
