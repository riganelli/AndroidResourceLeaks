import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;

public class DatabaseCloseTest {
	AppiumDriver driver;

    final String APP_PACKAGE = "com.ichi2.anki";
    final String APP_ACTIVITY = "com.ichi2.anki.StudyOptions";

    @Before
    public void SetUp() throws Exception {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "AndroidTestDevice");
        capabilities.setCapability(MobileCapabilityType.VERSION,"4.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

        //wait the activity
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);

    }
    
    @Test
    public void TestRun() throws IOException, InterruptedException{
    	driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/"
    			+ "android.widget.LinearLayout/android.widget.FrameLayout/"
    			+ "android.widget.LinearLayout/android.widget.LinearLayout/"
    			+ "android.widget.Button[1]")).click();
    	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.BACK);
    	
    	Thread.sleep(1000);
    	
    	Process process =Runtime.getRuntime().exec("adb shell dumpsys meminfo com.ichi2.anki");
        java.io.InputStream is = process.getInputStream();
        java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(is));

        String s = null;
        while ((s = reader.readLine()) != null) {
            if (s.contains("/AnkiDroid/country-capitals.anki")) {
            	assert false;
            }
        }
    	
    }
}