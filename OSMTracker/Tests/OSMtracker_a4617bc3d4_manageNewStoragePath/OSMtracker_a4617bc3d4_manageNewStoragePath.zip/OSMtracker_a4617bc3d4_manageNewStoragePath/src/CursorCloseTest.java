import io.appium.java_client.AppiumDriver;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
//import libs.TestHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class CursorCloseTest {
	AppiumDriver driver;

    final String APP_PACKAGE = "me.guillaumin.android.osmtracker";
    final String APP_ACTIVITY = "me.guillaumin.android.osmtracker.activity.TrackManager "; 



    @Before
    public void SetUp() throws Exception {
    		//first of all: enable gps
        Process processGPS = Runtime.getRuntime().exec("adb shell settings put secure location_providers_allowed gps");
    		Process process = Runtime.getRuntime().exec("adb install Utils/TrackManager.apk");
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability(MobileCapabilityType.VERSION,"5.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);
        capabilities.setCapability("no-reset"," false");
			
}

	@After
	public void TearDown()throws Exception{
	}
	
	@Test
	public void TestRun () throws IOException, InterruptedException{
			((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.MENU);
			Thread.sleep(2000);
			findElementByText("New track","android.widget.TextView").click();
			findElementByText("Restriction","android.widget.Button").click();
			((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.MENU);
			findElementByText("Stop & save","android.widget.TextView").click();
			((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
			Thread.sleep(2000);
			Process installUpdate = Runtime.getRuntime().exec("adb install -r /Utils/osmtracker-android.apk");
			Thread.sleep(2000);
			Process openApp = Runtime.getRuntime().exec("adb shell am start -n me.guillaumin.android.osmtracker/me.guillaumin.android.osmtracker.activity.TrackManager ");
			Thread.sleep(3000);
			Runtime.getRuntime().exec("adb uninstall me.guillaumin.android.osmtracker");
	}
	
	public WebElement findElementByText(String toSearch, String className) {
    	List<WebElement> elements = driver.findElementsByClassName(className);
    	for(WebElement  element: elements){
    		if(element.getText().equalsIgnoreCase(toSearch)) {
    			return element;
    		}
    	}
    	return null;
    }
    

}