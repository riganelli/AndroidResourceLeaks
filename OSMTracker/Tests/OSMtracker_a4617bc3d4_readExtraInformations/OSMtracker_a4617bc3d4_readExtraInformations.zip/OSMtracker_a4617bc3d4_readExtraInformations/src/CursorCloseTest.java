import io.appium.java_client.AppiumDriver;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
//import libs.TestHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;

public class CursorCloseTest {
	AppiumDriver driver;

    final String APP_PACKAGE = "me.guillaumin.android.osmtracker";
    final String APP_ACTIVITY = "me.guillaumin.android.osmtracker.activity.TrackManager "; 



    @Before
    public void SetUp() throws Exception {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability(MobileCapabilityType.VERSION,"5.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);

    }
    
    @After
    public void TearDown()throws Exception{
    }

    @Test
    public void TestRun () throws IOException, InterruptedException{
    		((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.MENU);
    		driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.view.View/android.widget.TextView[1]")).click();
    		((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.MENU);
    		driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.view.View/android.widget.TextView[1]")).click();
    		Thread.sleep(2000);
    		driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout/android.widget.RelativeLayout")).click();
    		Thread.sleep(2000);
    		((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.HOME);
    }
    
}