/** Automatically generated file. DO NOT MODIFY */
package de.ub0r.android.callmeter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}