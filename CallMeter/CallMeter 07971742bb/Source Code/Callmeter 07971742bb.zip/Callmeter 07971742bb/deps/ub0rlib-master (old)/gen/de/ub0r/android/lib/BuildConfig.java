/** Automatically generated file. DO NOT MODIFY */
package de.ub0r.android.lib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}