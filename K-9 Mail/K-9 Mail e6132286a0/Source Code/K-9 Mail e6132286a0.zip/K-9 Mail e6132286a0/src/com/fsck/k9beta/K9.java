package com.fsck.k9beta;

import com.android.email.Email;

public class K9 extends Email {
}
