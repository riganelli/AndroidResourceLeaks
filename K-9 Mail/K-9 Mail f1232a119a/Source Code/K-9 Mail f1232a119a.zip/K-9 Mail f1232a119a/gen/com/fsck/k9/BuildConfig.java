/** Automatically generated file. DO NOT MODIFY */
package com.fsck.k9;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}