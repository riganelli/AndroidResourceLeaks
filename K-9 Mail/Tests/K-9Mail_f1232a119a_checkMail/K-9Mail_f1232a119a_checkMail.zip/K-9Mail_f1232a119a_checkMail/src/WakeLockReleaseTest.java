import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.AndroidMobileCapabilityType;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class WakeLockReleaseTest {
	AppiumDriver driver;
	
	final String APP_PACKAGE = "com.fsck.k9";
	final String APP_ACTIVITY = "com.android.email.activity.Welcome"; 

    @Before
    public void SetUp() throws Exception {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "AndroidTestDevice");
        capabilities.setCapability(MobileCapabilityType.VERSION,"4.1.1");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, APP_PACKAGE);
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, APP_ACTIVITY);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

        //wait the activity
        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, APP_ACTIVITY);

    }

    @Test
    public void TestRun () throws IOException, InterruptedException{
    	
    	((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.MENU);
    	
    	findElementByText("Check mail","android.widget.TextView").click();
    	
    	Process process = Runtime.getRuntime().exec("adb shell dumpsys power");
        java.io.InputStream is = process.getInputStream();
        java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(is));
        
        String s = null;
        while ((s = reader.readLine()) != null) {
            if (s.contains("PARTIAL_WAKE_LOCK              'Email'")) {
                assert false;
            }
        }
    	
    }
    public WebElement findElementByText(String toSearch, String className) {
    	List<WebElement> elements = driver.findElementsByClassName(className);
    	for(WebElement  element: elements){
    		if(element.getText().equalsIgnoreCase(toSearch)) {
    			return element;
    		}
    	}
    	return null;
    }
}
